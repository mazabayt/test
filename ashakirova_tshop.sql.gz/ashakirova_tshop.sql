-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `tel` text NOT NULL,
  `id_sale` int(11) NOT NULL,
  KEY `ID` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `orders` (`ID`, `name`, `email`, `tel`, `id_sale`) VALUES
(1,	'domamon',	'123@mail.ert',	'+79999999999',	14),
(2,	'domamon',	'123@mail.ert',	'+79999999999',	10),
(3,	'domamon',	'123@mail.ert',	'+79999999999',	16),
(4,	'domamon',	'123@mail.ert',	'+79999999999',	10),
(5,	'Максим',	'simple@min.co',	'+791131534864',	2),
(6,	'Максим',	'simple@min.co',	'+791131534864',	2),
(7,	'Максим',	'simple@min.co',	'+791131534864',	3),
(8,	'ssdfsdf',	'simple@gmail.ru',	'+79999999999',	2),
(9,	'ssdfsdf',	'simple@gmail.ru',	'+79999999999',	3),
(10,	'asd',	'fgh@dfg',	'+791131534864',	3),
(11,	'123',	'sdf@asd.ru',	'123',	6),
(12,	'ssdfsdf',	'fgh@dfg',	'se',	16),
(13,	'ssdfsdf',	'fgh@dfg',	'+79999999999',	8),
(14,	'ssdfsdf',	'fgh@dfg',	'+79999999999',	8),
(15,	'123',	'fgh@dfg',	'se',	2),
(16,	'123',	'fgh@dfg',	'se',	2),
(17,	'123',	'fgh@dfg',	'+79999999999',	5),
(18,	'123',	'sdf@asd.ru',	'123',	2),
(19,	'dron',	'123@mail.ert',	'se',	2),
(20,	'123',	'fgh@dfg',	'se',	9),
(21,	'123',	'fgh@dfg',	'se',	9),
(22,	'123',	'fgh@dfg',	'se',	3),
(23,	'123',	'123@mail.ert',	'se',	2),
(24,	'jhg\'',	'fgh@dfg',	'se',	3),
(25,	'vas\'',	'fg\'h@dfg',	'+79999999999',	8),
(26,	'gch',	'sdf@asd.ru',	'+79999999999',	1),
(27,	'123',	'',	'se',	2),
(28,	'123\'',	'',	'se',	1),
(29,	'123\'',	'',	'se',	3),
(30,	'ssdfsdf',	'',	'+79999999999',	6),
(31,	'asd',	'fgh@dfg',	'+79999999999',	3),
(32,	'asd\'hfggfh',	'fgh@dfg',	'+79999999999',	3),
(33,	'123',	'fgh@dfg',	'se',	2),
(34,	'123',	'fgh@dfg',	'se',	2),
(35,	'123',	'fgh@dfg',	'se',	2),
(36,	'123',	'fgh@dfg',	'se',	1),
(37,	'123',	'fgh@dfg',	'se',	3),
(38,	'uiasasd',	'123@mail.ert',	'213123',	1),
(39,	'ssdfsdf',	'sdf@asd.ru',	'sdf',	1),
(40,	'ssdfsdf',	'sdf@asd.ru',	'sdf',	16),
(41,	'ssdfsdf',	'sdf@asd.ru',	'sdf',	16),
(42,	'ssdfsdf',	'sdf@asd.ru',	'sdf',	16),
(43,	'ssdfsdf',	'sdf@asd.ru',	'sdf',	16),
(44,	'ssdfsdf',	'sdf@asd.ru',	'sdf',	16),
(45,	'sdfsd \'',	'sdf@asd.ru',	'sdf',	12),
(46,	'sdfsd \'',	'sdf@asd.ru',	'sdf',	16),
(47,	'sdfsd \'',	'sdf@asd.ru',	'sdf',	15),
(48,	'sdfsd \'',	'sdf@asd.ru',	'sdf',	11),
(49,	'asdas',	'sad@asd',	'asd',	2),
(50,	'vana',	'asd@kjhas',	'ewf33',	14),
(51,	'vana',	'asd@kjhas',	'ewf33',	14),
(52,	'asd',	'asdas',	'sad 2',	3),
(53,	'sdfs',	'dsfs',	'sdfs',	3),
(54,	'sd',	'asda',	'asd',	3),
(55,	'sd',	'asda',	'asd',	3),
(56,	'sd',	'asda@fas.ru',	'6854654',	5),
(57,	'sd',	'asda@fas.ru',	'6854654',	5),
(58,	'sd',	'asda@fas.ru',	'6854654',	5),
(59,	'sd',	'asda@fas.ru',	'6854654',	5),
(60,	'asd',	'asd@kjhas',	'asd',	3),
(61,	'asd',	'asd@kjhas',	'asd',	3),
(62,	'asd',	'asd@kjhas',	'asd',	3),
(63,	'asd',	'asd@kjhas',	'asd',	5),
(64,	'asd',	'asd@kjhas',	'asd',	5),
(65,	'vana',	'asd@kjhas',	'ewf33',	3),
(66,	'vana',	'asd@kjhas',	'asd',	4),
(67,	'vana',	'asd@kjhas',	'asd',	5),
(68,	'vana',	'asd@kjhas',	'asd',	5),
(69,	'vana',	'asd@kjhas',	'asd',	3),
(70,	'vana',	'asd@kjhas',	'asd',	3),
(71,	'vana',	'asd@kjhas',	'asd',	5);

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `feedback` longtext NOT NULL,
  `name` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `reviews` (`ID`, `feedback`, `name`) VALUES
(1,	'мне настолько всё понравилось. что у меня даже нет слов',	NULL),
(2,	'спасибо, было вкусно',	'Андрей Генадьевич'),
(3,	'гнп опропфцу а7е 362п 3нг 3нпе гнпармиывао длод рфра ',	'Михаил Петрович'),
(6,	'<script>',	'<script>'),
(24,	'ok sps',	'Pavel Ivanovich');

DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `picture` text NOT NULL,
  `about` text NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `sales` (`ID`, `name`, `picture`, `about`, `price`) VALUES
(1,	'Продукт №1',	'/images/1.jpg',	'Вашему вниманию представлен товар № 1',	14),
(2,	'Продукт №2',	'/images/2.jpg',	'Вашему вниманию представлен товар № 2',	13),
(3,	'Продукт №3',	'/images/3.jpg',	'Вашему вниманию представлен товар № 3',	5413),
(4,	'Продукт №4',	'/images/1.jpg',	'Вашему вниманию представлен товар № 4',	0),
(5,	'Продукт №5',	'/images/2.jpg',	'Вашему вниманию представлен товар № 5',	798),
(6,	'Продукт №6',	'/images/3.jpg',	'Вашему вниманию представлен товар № 6',	6546),
(7,	'Продукт №7',	'/images/1.jpg',	'Вашему вниманию представлен товар № 7',	777),
(8,	'Продукт №8',	'/images/2.jpg',	'Вашему вниманию представлен товар № 8',	897),
(9,	'Продукт №9',	'/images/3.jpg',	'Вашему вниманию представлен товар № 9',	123),
(10,	'Продукт №10',	'/images/1.jpg',	'Вашему вниманию представлен товар № 10',	10),
(11,	'Продукт №11',	'/images/2.jpg',	'Вашему вниманию представлен товар № 11',	1485),
(12,	'Продукт №12',	'/images/3.jpg',	'Вашему вниманию представлен товар № 12',	1612),
(13,	'Продукт №13',	'/images/1.jpg',	'Вашему вниманию представлен товар № 13',	988),
(14,	'Продукт №14',	'/images/2.jpg',	'Вашему вниманию представлен товар № 14',	1),
(15,	'Продукт №15',	'/images/3.jpg',	'Вашему вниманию представлен товар № 15',	32),
(16,	'Продукт №16',	'/images/1.jpg',	'Вашему вниманию представлен товар № 16',	6500);

-- 2020-10-30 08:59:36
